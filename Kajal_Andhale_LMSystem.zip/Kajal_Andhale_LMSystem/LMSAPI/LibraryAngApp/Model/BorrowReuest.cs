﻿namespace LibraryAngApp.Model
{
    public class BorrowReuest
    {
        public int BookId { get; set; }
        public int ParticipantId { get; set; }
    }
}
