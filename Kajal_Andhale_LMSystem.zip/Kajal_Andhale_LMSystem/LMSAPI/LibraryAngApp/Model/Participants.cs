﻿namespace LibraryAngApp.Model
{
    public class Participants
    {
        public int id { get; set; }

        public string name { get; set; }
        public string email { get; set; }
        public int asignedBooks { get; set; }
        public List<Books> assignedBooks { get; set; } = new List<Books>();
    }
}
