﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using LibraryAngApp.Model;

namespace LibraryAngApp.Data
{
    public class LibraryAngAppContext : DbContext
    {
        public LibraryAngAppContext (DbContextOptions<LibraryAngAppContext> options)
            : base(options)
        {
        }

        public DbSet<LibraryAngApp.Model.Books> Books { get; set; } = default!;
        public DbSet<LibraryAngApp.Model.Participants> Participants { get; set; } = default!;
        public DbSet<LibraryAngApp.Model.Users> Users { get; set; } = default!;


    }
}
