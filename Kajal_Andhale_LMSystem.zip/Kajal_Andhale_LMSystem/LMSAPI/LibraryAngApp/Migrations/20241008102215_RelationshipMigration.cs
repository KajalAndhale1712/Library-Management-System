﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LibraryAngApp.Migrations
{
    /// <inheritdoc />
    public partial class RelationshipMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Participantsid",
                table: "Books",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Books_Participantsid",
                table: "Books",
                column: "Participantsid");

            migrationBuilder.AddForeignKey(
                name: "FK_Books_Participants_Participantsid",
                table: "Books",
                column: "Participantsid",
                principalTable: "Participants",
                principalColumn: "id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Books_Participants_Participantsid",
                table: "Books");

            migrationBuilder.DropIndex(
                name: "IX_Books_Participantsid",
                table: "Books");

            migrationBuilder.DropColumn(
                name: "Participantsid",
                table: "Books");
        }
    }
}
