﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LibraryAngApp.Data;
using LibraryAngApp.Model;

namespace LibraryAngApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private readonly LibraryAngAppContext _context;

        public BooksController(LibraryAngAppContext context)
        {
            _context = context;
        }

        // GET: api/Books
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Books>>> GetBooks()
        {
            return await _context.Books.ToListAsync();
        }

        // GET: api/Books/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Books>> GetBooks(int id)
        {
            var book = await _context.Books.FindAsync(id);

            if (book == null)
            {
                return NotFound();
            }

            return book;
        }

        // PUT: api/Books/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutBooks(int id, Books book)
        {
            if (id != book.id)
            {
                return BadRequest();
            }

            _context.Entry(book).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BooksExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Books
        [HttpPost]
        public async Task<ActionResult<Books>> PostBooks(Books book)
        {
            _context.Books.Add(book);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetBooks", new { id = book.id }, book);
        }

        // DELETE: api/Books/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBooks(int id)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null)
            {
                return NotFound();
            }

            _context.Books.Remove(book);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // POST: api/Books/borrow/{id}
        [HttpPost("borrow/{id}")]
        public async Task<IActionResult> BorrowBook(int id, [FromBody] int participantId)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null || book.availableCopies <= 0)
            {
                return NotFound("Book not found or no available copies.");
            }

            // Decrease available copies
            book.availableCopies--;
            await _context.SaveChangesAsync();

            // Optionally, you can track which participant borrowed the book
            // Add logic to associate the borrowed book with the participant here

            return NoContent();
        }


        [HttpPost("borrow")]
        public async Task<IActionResult> BorrowBook([FromBody] BorrowReuest request)
        {
            var book = await _context.Books.FindAsync(request.BookId);
            var participant = await _context.Participants.FindAsync(request.ParticipantId);

            if (book == null || participant == null)
            {
                return NotFound("Book or Participant not found.");
            }

            if (book.availableCopies <= 0)
            {
                return BadRequest("No available copies.");
            }

            // Update the book's available copies
            book.availableCopies--;

            // Add book to participant's assignedBooks
            participant.assignedBooks.Add(book);

            await _context.SaveChangesAsync();

            return Ok();
        }


        [HttpPut("return/{bookId}")]
        public IActionResult ReturnBook(int bookId, [FromBody] BorrowReuest request)
        {
            // Validate request
            if (request == null || request.ParticipantId <= 0)
            {
                return BadRequest("Invalid request data.");
            }

            // Find the book by its ID
            var book = _context.Books.Find(bookId);
            if (book == null)
            {
                return NotFound("Book not found.");
            }

            // Find the participant by their ID
            var participant = _context.Participants
                .Include(p => p.assignedBooks) // Assuming you have a navigation property
                .FirstOrDefault(p => p.id == request.ParticipantId);

            if (participant == null)
            {
                return NotFound("Participant not found.");
            }

            // Remove the book from the participant's assigned books
            var assignedBook = participant.assignedBooks.FirstOrDefault(b => b.id == bookId);
            if (assignedBook != null)
            {
                participant.assignedBooks.Remove(assignedBook);
                book.availableCopies++; // Increase available copies
            }
            else
            {
                return BadRequest("This book was not assigned to the participant.");
            }

            // Save changes to the database
            _context.SaveChanges();

            return NoContent(); // Indicate success without a response body
        }


        // POST: api/Books/return/{id}
        [HttpPost("return/{id}")]
        public async Task<IActionResult> ReturnBook(int id, [FromBody] int participantId)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null)
            {
                return NotFound("Book not found.");
            }

            // Increase available copies
            book.availableCopies++;
            await _context.SaveChangesAsync();

            // Optionally, you can track which participant returned the book here

            return NoContent();
        }


        private bool BooksExists(int id)
        {
            return _context.Books.Any(e => e.id == id);
        }
    }
}
