﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LibraryAngApp.Data;
using LibraryAngApp.Model;

namespace LibraryAngApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly LibraryAngAppContext _context;

        public UsersController(LibraryAngAppContext context)
        {
            _context = context;
        }

        // GET: api/Users
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Users>>> GetUsers()
        {
            return await _context.Users.ToListAsync();
        }

        // GET: api/Users/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Users>> GetUsers(int id)
        {
            var users = await _context.Users.FindAsync(id);

            if (users == null)
            {
                return NotFound();
            }

            return users;
        }

        // PUT: api/Users/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutUsers(int id, Users users)
        {
            if (id != users.Id)
            {
                return BadRequest();
            }

            _context.Entry(users).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UsersExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Users/register
        [HttpPost("register")]
        public async Task<ActionResult<Users>> Register(Users users)
        {
            if (users == null || string.IsNullOrWhiteSpace(users.Email) || string.IsNullOrWhiteSpace(users.Password))
            {
                return BadRequest("Invalid user data.");
            }

            // Check if the user already exists
            if (await _context.Users.AnyAsync(u => u.Email == users.Email))
            {
                return Conflict("User already exists.");
            }

            // TODO: Hash the password before storing
            users.Password = HashPassword(users.Password); // Implement this method

            _context.Users.Add(users);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetUsers", new { id = users.Id }, users);
        }

        // POST: api/Users/login
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest loginRequest)
        {
            if (loginRequest == null || string.IsNullOrWhiteSpace(loginRequest.Email) || string.IsNullOrWhiteSpace(loginRequest.Password))
            {
                return BadRequest("Invalid login data.");
            }

            var user = await _context.Users.SingleOrDefaultAsync(u => u.Email == loginRequest.Email);

            if (user == null || !VerifyPassword(loginRequest.Password, user.Password)) // Implement VerifyPassword
            {
                return Unauthorized("Invalid email or password.");
            }

            // Optionally return user details or a token
            return Ok(new { user.Id, user.Name, user.Email, user.Role });
        }

        // DELETE: api/Users/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUsers(int id)
        {
            var users = await _context.Users.FindAsync(id);
            if (users == null)
            {
                return NotFound();
            }

            _context.Users.Remove(users);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool UsersExists(int id)
        {
            return _context.Users.Any(e => e.Id == id);
        }

        // Example methods for password hashing and verification
        private string HashPassword(string password)
        {
            // Implement password hashing logic (e.g., BCrypt)
            return password; // Replace with hashed password
        }

        private bool VerifyPassword(string password, string hashedPassword)
        {
            // Implement password verification logic (e.g., BCrypt)
            return password == hashedPassword; // Replace with actual verification
        }
    }

    // Login request model
    public class LoginRequest
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
