﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LibraryAngApp.Data;
using LibraryAngApp.Model;

namespace LibraryAngApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ParticipantsController : ControllerBase
    {
        private readonly LibraryAngAppContext _context;

        public ParticipantsController(LibraryAngAppContext context)
        {
            _context = context;
        }

        // GET: api/Participants
        [HttpGet]
        public async Task<ActionResult<IEnumerable<DTOParticipants>>> GetParticipants()
        {
            var participants = await _context.Participants
                .Include(p => p.assignedBooks) // Ensure you're using the correct property name
                .ToListAsync();

            var dtoParticipants = participants.Select(p => new DTOParticipants
            {
                id = p.id,
                name = p.name,
                email = p.email,
                assignedBooks = p.assignedBooks.ToList() // Adjust if needed
            }).ToList();

            return dtoParticipants;
        }

        // GET: api/Participants/5
        [HttpGet("{id}")]
        public async Task<ActionResult<DTOParticipants>> GetParticipant(int id)
        {
            var participant = await _context.Participants.Include(p => p.assignedBooks)
                .Where(p => p.id == id)
                .Select(p => new DTOParticipants
                {
                    id = p.id,
                    name = p.name,
                    email = p.email,
                    assignedBooks = p.assignedBooks.ToList()
                })
                .FirstOrDefaultAsync();

            if (participant == null)
            {
                return NotFound();
            }

            return participant;
        }

        // PUT: api/Participants/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutParticipant(int id, DTOParticipants dtoParticipant)
        {
            if (id != dtoParticipant.id)
            {
                return BadRequest();
            }

            var participant = await _context.Participants.FindAsync(id);
            if (participant == null)
            {
                return NotFound();
            }

            participant.name = dtoParticipant.name;
            participant.email = dtoParticipant.email;
            // Handle assignedBooks logic as needed, e.g., clear old and add new

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ParticipantsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Participants
        [HttpPost]
        public async Task<ActionResult<Participants>> PostParticipant(DTOParticipants dtoParticipant)
        {
            var participant = new Participants
            {
                name = dtoParticipant.name,
                email = dtoParticipant.email,
                assignedBooks = dtoParticipant.assignedBooks // Assuming a relationship is set up
            };

            _context.Participants.Add(participant);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetParticipant", new { id = participant.id }, participant);
        }

        // DELETE: api/Participants/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteParticipant(int id)
        {
            var participant = await _context.Participants.FindAsync(id);
            if (participant == null)
            {
                return NotFound();
            }

            _context.Participants.Remove(participant);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // POST: api/Participants/borrow/{participantId}
        [HttpPost("borrow/{participantId}")]
        public async Task<IActionResult> BorrowBook(int participantId, [FromBody] int bookId)
        {
            var participant = await _context.Participants.Include(p => p.assignedBooks)
                .FirstOrDefaultAsync(p => p.id == participantId);
            var book = await _context.Books.FindAsync(bookId);

            if (participant == null || book == null || book.availableCopies <= 0)
            {
                return NotFound("Participant or book not found, or no available copies.");
            }

            // Add the book to the participant's assignedBooks
            participant.assignedBooks.Add(book);
            book.availableCopies--;

            await _context.SaveChangesAsync();

            return NoContent();
        }

        // POST: api/Participants/return/{participantId}
        [HttpPost("return/{participantId}")]
        public async Task<IActionResult> ReturnBook(int participantId, [FromBody] int bookId)
        {
            var participant = await _context.Participants.Include(p => p.assignedBooks)
                .FirstOrDefaultAsync(p => p.id == participantId);
            var book = await _context.Books.FindAsync(bookId);

            if (participant == null || book == null)
            {
                return NotFound("Participant or book not found.");
            }

            // Remove the book from the participant's assignedBooks
            if (participant.assignedBooks.Remove(book))
            {
                book.availableCopies++;
                await _context.SaveChangesAsync();
            }
            else
            {
                return BadRequest("The participant does not have this book assigned.");
            }

            return NoContent();
        }

        private bool ParticipantsExists(int id)
        {
            return _context.Participants.Any(e => e.id == id);
        }
    }
}
