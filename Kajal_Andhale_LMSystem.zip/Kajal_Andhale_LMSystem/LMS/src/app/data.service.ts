// import { HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';
// import { Observable } from 'rxjs';

// export interface Book {
//   id?: number;
//   title: string;
//   author: string;
//   availableCopies: number;
// }

// @Injectable({
//   providedIn: 'root'
// })
// export class DataService {

//   private apiUrl = 'http://localhost:5118/api/Books'; 

//   constructor(private http: HttpClient) {}

//   addBook(book: Book): Observable<Book> {
//     return this.http.post<Book>(this.apiUrl, book);
//   }

//   getBooks(): Observable<Book[]> {
//     return this.http.get<Book[]>(this.apiUrl);
//   }

// }

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface Book {
  id: number; // Remove the optional modifier
  title: string;
  author: string;
  availableCopies: number;
}


@Injectable({
  providedIn: 'root'
})
export class DataService {
  private apiUrl = 'http://localhost:5118/api/Books'; 

  constructor(private http: HttpClient) {}

  addBook(book: Book): Observable<Book> {
    return this.http.post<Book>(this.apiUrl, book);
  }

  getBooks(): Observable<Book[]> {
    return this.http.get<Book[]>(this.apiUrl);
  }

updateBook(book: Book): Observable<Book> {
  return this.http.put<Book>(`${this.apiUrl}/${book.id}`, book);
}

borrowBook(bookId: number, participantId: number): Observable<void> {
  return this.http.post<void>(`${this.apiUrl}/borrow`, { bookId, participantId });
}

returnBook(bookId: number, participantId: number): Observable<void> {
  return this.http.put<void>(`${this.apiUrl}/return/${bookId}`, { participantId });
}
removeBook(bookId: number): Observable<void> {
  return this.http.delete<void>(`${this.apiUrl}/${bookId}`);
}



}
