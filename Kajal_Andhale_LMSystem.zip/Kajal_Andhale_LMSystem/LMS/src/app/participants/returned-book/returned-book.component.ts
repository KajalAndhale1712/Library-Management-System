import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DataService } from '../../data.service';
import { ParticipantsService, Participant } from '../../participants.service';
import { CommonModule } from '@angular/common';
import { HttpClientXsrfModule } from '@angular/common/http';

@Component({
  selector: 'app-returned-book',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, HttpClientXsrfModule],
  templateUrl: './returned-book.component.html',
  styleUrls: ['./returned-book.component.css']
})
export class ReturnedBookComponent implements OnInit {
  returnForm: FormGroup;
  participants: Participant[] = [];
  books: any[] = [];

  constructor(
    private fb: FormBuilder,
    private dataService: DataService,
    private participantsService: ParticipantsService
  ) {
    this.returnForm = this.fb.group({
      participantId: [''],
      bookId: ['']
    });
  }

  ngOnInit(): void {
    this.loadParticipants();
    this.loadBooks();
  }

  loadParticipants() {
    this.participantsService.getParticipants().subscribe(data => {
      this.participants = data;
    });
  }

  loadBooks() {
    this.dataService.getBooks().subscribe(data => {
      this.books = data;
    });
  }

  onSubmits() {
    const { participantId, bookId } = this.returnForm.value;

    this.dataService.returnBook(bookId, participantId).subscribe(() => {
      this.updateParticipantAssignedBooks(participantId, bookId);
      this.increaseBookCopies(bookId);
      alert('Book returned successfully!');
    }, error => {
      console.error('Error returning book:', error);
      alert('An error occurred while returning the book.');
    });
  }

  private updateParticipantAssignedBooks(participantId: number, bookId: number) {
    const participant = this.participants.find(p => p.id === participantId);
    if (participant) {
      participant.assignedBooks = participant.assignedBooks.filter(book => book.id !== bookId);
      this.participantsService.updateParticipant(participant).subscribe(() => {
        console.log('Participant updated successfully.');
      }, error => {
        console.error('Error updating participant:', error);
      });
    }
  }

  private increaseBookCopies(bookId: number) {
    const book = this.books.find(b => b.id === bookId);
    if (book) {
      book.availableCopies++;
      this.dataService.updateBook(book).subscribe(() => {
        console.log('Book copies updated successfully.');
      }, error => {
        console.error('Error updating book copies:', error);
      });
    }
  }
}
