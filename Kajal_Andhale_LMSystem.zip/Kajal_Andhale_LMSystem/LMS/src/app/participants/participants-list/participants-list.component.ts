import { Component } from '@angular/core';
import { Participant, ParticipantsService } from '../../participants.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AddParticipantsComponent } from '../add-participants/add-participants.component';
import { Router } from '@angular/router';


@Component({
  selector: 'app-participants-list',
  standalone: true,
  imports: [FormsModule,CommonModule,ReactiveFormsModule,AddParticipantsComponent],
  templateUrl: './participants-list.component.html',
  styleUrl: './participants-list.component.css'
})
export class ParticipantsListComponent {
  participants: Participant[] = [];

  constructor(private participantService: ParticipantsService,private router :Router) {}

  ngOnInit() {
    this.loadParticipants();
  }

  loadParticipants() {
    this.participantService.getParticipants().subscribe({
      next: (data) => this.participants = data,
      error: (err) => console.error('Error loading participants:', err)
    });
  }

  addParticipant()
{
  this.router.navigate(['add-participant']);

}

onSubmit(){
  this.router.navigate(['borrow-book']);

}
onSubmits(){
  this.router.navigate(['return-book']);
}
}
