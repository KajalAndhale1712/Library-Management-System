import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { DataService } from '../../data.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { ParticipantsService } from '../../participants.service';

@Component({
  selector: 'app-add-participants',
  standalone: true,
  imports: [CommonModule,FormsModule,ReactiveFormsModule,HttpClientModule],
  templateUrl: './add-participants.component.html',
  styleUrl: './add-participants.component.css'
})
export class AddParticipantsComponent {
  participantForm: FormGroup;

  constructor(private fb: FormBuilder, private participantService: ParticipantsService, private router: Router) {
    this.participantForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]]
    });
  }

  onSubmit() {
    if (this.participantForm.valid) {
      this.participantService.addParticipant(this.participantForm.value).subscribe({
        next: () => this.router.navigate(['/participants-list']),
        error: (err) => console.error('Error adding participant:', err)
      });
    }
  }

}
