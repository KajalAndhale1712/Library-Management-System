// import { HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';
// import { Observable } from 'rxjs';

// export interface Participant {
//   id: number;
//   name: string;
//   email: string;
//   assignedBooks: any[]; 
// }

// @Injectable({
//   providedIn: 'root'
// })
// export class ParticipantsService {

//   private apiUrl = 'http://localhost:5118/api/Participants'; 

//   constructor(private http: HttpClient) { }

//   getParticipants(): Observable<Participant[]> {
//     return this.http.get<Participant[]>(this.apiUrl);
//   }

//   addParticipant(participant: Participant): Observable<Participant> {
//     return this.http.post<Participant>(this.apiUrl, participant);
//   }
// }

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Book } from './data.service';

export interface Participant {
  id: number;
  name: string;
  email: string;
  assignedBooks: Book[]; 
}

@Injectable({
  providedIn: 'root'
})
export class ParticipantsService {
  private apiUrl = 'http://localhost:5118/api/Participants'; 

  constructor(private http: HttpClient) {}

  getParticipants(): Observable<Participant[]> {
    return this.http.get<Participant[]>(this.apiUrl);
  }

  addParticipant(participant: Participant): Observable<Participant> {
    return this.http.post<Participant>(this.apiUrl, participant);
  }


updateParticipant(participant: Participant): Observable<Participant> {
  return this.http.put<Participant>(`${this.apiUrl}/${participant.id}`, participant);
}

  borrowBook(bookId: number, participantId: number): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/borrow/${bookId}`, { participantId });
  }
  
  returnBook(bookId: number, participantId: number): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/return/${bookId}`, { participantId });
  }
}
