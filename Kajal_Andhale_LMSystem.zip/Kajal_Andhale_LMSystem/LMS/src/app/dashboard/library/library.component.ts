import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-library',
  standalone: false,
  templateUrl: './library.component.html',
  styleUrl: './library.component.css'
})
export class LibraryComponent {
  constructor(private router:Router){}
  addBook() {
    this.router.navigate(['book-list']);
  }

  addParticipant(){
    this.router.navigate(['participants-list']);

  }
  // onSubmit(){
  //   this.router.navigate(['borrow-book']);

  // }
  // onSubmits(){
  //   this.router.navigate(['return-book']);
  // }

}
