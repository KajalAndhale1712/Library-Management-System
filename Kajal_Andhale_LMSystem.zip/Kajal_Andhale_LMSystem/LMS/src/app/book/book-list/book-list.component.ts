import { Component, OnInit } from '@angular/core';
import { Book, DataService } from '../../data.service';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
import { AddBookComponent } from '../add-book/add-book.component';
import { AddParticipantsComponent } from '../../participants/add-participants/add-participants.component';
import { BorrowBookComponent } from '../borrow-book/borrow-book.component';
import { ReturnedBookComponent } from '../../participants/returned-book/returned-book.component';

@Component({
  selector: 'app-book-list',
  standalone: true,
  imports: [CommonModule,FormsModule,HttpClientModule,ReactiveFormsModule,
    AddBookComponent,AddParticipantsComponent,BorrowBookComponent,ReturnedBookComponent],
  templateUrl: './book-list.component.html',
  styleUrl: './book-list.component.css'
})
export class BookListComponent implements OnInit {
  books: Book[] = [];

  constructor(private bookService: DataService,private router:Router) {}

  ngOnInit(): void {
    this.loadBooks();
  }

  loadBooks(): void {
    this.bookService.getBooks().subscribe({
      next: (books) => {
        this.books = books;
      },
      error: (err) => {
        console.error('Error loading books:', err);
      }
    });
  }
  
  addBook() {
    this.router.navigate(['add-book']);
  }

  addParticipant(){
    this.router.navigate(['participants-list']);

  }

  onSubmit(){
    this.router.navigate(['borrow-book']);

  }
  onSubmits(){
    this.router.navigate(['return-book']);
  }

  editBook(book: Book) {
    this.router.navigate(['edit-book', book.id]); 
  }

  removeBook(bookId: number) {
    if (confirm('Are you sure you want to remove this book?')) {
      this.bookService.removeBook(bookId).subscribe({
        next: () => {
          this.loadBooks();
        },
        error: (err) => {
          console.error('Error removing book:', err);
        }
      });
    }
  }
  
}