import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Book, DataService } from '../../data.service';
import { Participant, ParticipantsService } from '../../participants.service';
import { CommonModule } from '@angular/common';
import { HttpClientXsrfModule } from '@angular/common/http';

@Component({
  selector: 'app-borrow-book',
  standalone: true,
  imports: [CommonModule,FormsModule,ReactiveFormsModule,HttpClientXsrfModule],
  templateUrl: './borrow-book.component.html',
  styleUrl: './borrow-book.component.css'
})
export class BorrowBookComponent implements OnInit {
  borrowForm: FormGroup;
  participants: any[] = [];
  books: any[] = [];

  constructor(
    private fb: FormBuilder,
    private dataService: DataService,
    private participantsService: ParticipantsService
  ) {
    this.borrowForm = this.fb.group({
      participantId: [''],
      bookId: ['']
    });
  }

  ngOnInit(): void {
    this.loadParticipants();
    this.loadBooks();
  }

  loadParticipants() {
    this.participantsService.getParticipants().subscribe(data => {
      this.participants = data;
    });
  }

  loadBooks() {
    this.dataService.getBooks().subscribe(data => {
      this.books = data;
    });
  }

  onSubmit() {
    const { participantId, bookId } = this.borrowForm.value;

    this.dataService.borrowBook(bookId, participantId).subscribe(() => {
      this.loadBooks();
      alert('Book borrowed successfully!');
    });
  }
}