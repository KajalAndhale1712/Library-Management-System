import { Routes } from '@angular/router';
import { AddBookComponent } from './book/add-book/add-book.component';
import { BookListComponent } from './book/book-list/book-list.component';
import { AddParticipantsComponent } from './participants/add-participants/add-participants.component';
import { ParticipantsListComponent } from './participants/participants-list/participants-list.component';
import { BorrowBookComponent } from './book/borrow-book/borrow-book.component';
import { ReturnedBookComponent } from './participants/returned-book/returned-book.component';
import { LibraryComponent } from './dashboard/library/library.component';
import { LoginComponent } from './authentication/login/login.component';
import { RegisterComponent } from './authentication/register/register.component';

export const routes: Routes = [
    
    { path: 'display', component: LibraryComponent },
    
    { path: 'add-book', component: AddBookComponent },
    { path: 'book-list', component: BookListComponent },

    { path: 'add-participant', component: AddParticipantsComponent },
    { path: 'participants-list', component: ParticipantsListComponent },
   
    { path: 'borrow-book', component: BorrowBookComponent },
    { path: 'return-book', component: ReturnedBookComponent },

    { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  
  { path: '', redirectTo: '/register', pathMatch: 'full' }
   
   

];
