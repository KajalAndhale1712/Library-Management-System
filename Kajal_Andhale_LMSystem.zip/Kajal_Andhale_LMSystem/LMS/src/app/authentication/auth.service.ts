import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

export interface User {
  id?: number;
  name: string;
  email: string;
  password: string;
  role: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private apiUrl = 'http://localhost:5118/api/Users';
  private user: User | null = null;

  constructor(private http: HttpClient, private router: Router) {}

  register(userData: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/register`, userData);
  }

  login(userData: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/login`, userData);
  }

  setUser(user: User) {
    this.user = user;
    localStorage.setItem('user', JSON.stringify(user));
  }

  getUser(): User | null {
    if (!this.user) {
      const userJson = localStorage.getItem('user');
      this.user = userJson ? JSON.parse(userJson) : null;
    }
    return this.user;
  }

  logout() {
    this.user = null;
    localStorage.removeItem('user');
    this.router.navigate(['/login']);
  }

  isAdmin(): boolean {
    const user = this.getUser();
    return user ? user.role === 'admin' : false;
  }
}
